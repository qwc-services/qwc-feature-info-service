--
-- PostgreSQL database dump
--

-- Dumped from database version 9.6.6
-- Dumped by pg_dump version 11.1

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;

SET check_function_bodies = false;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: test; Type: SCHEMA; Schema: -; Owner: sogis_test
--

CREATE SCHEMA test;


ALTER SCHEMA test OWNER TO sogis_test;

--
-- Name: postgis; Type: EXTENSION; Schema: -; Owner: 
--




--
-- Name: EXTENSION postgis; Type: COMMENT; Schema: -; Owner: 
--




SET default_tablespace = '';

SET default_with_oids = false;

--
-- Name: test_points; Type: TABLE; Schema: test; Owner: sogis_test
--

CREATE TABLE test.test_points (
    id integer NOT NULL,
    name character varying(32),
    beschreibung text,
    geom public.geometry(Point,2056)
);


ALTER TABLE test.test_points OWNER TO sogis_test;

--
-- Name: test_points_id_seq; Type: SEQUENCE; Schema: test; Owner: sogis_test
--

CREATE SEQUENCE test.test_points_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE test.test_points_id_seq OWNER TO sogis_test;

--
-- Name: test_points_id_seq; Type: SEQUENCE OWNED BY; Schema: test; Owner: sogis_test
--

ALTER SEQUENCE test.test_points_id_seq OWNED BY test.test_points.id;


--
-- Name: test_polygons; Type: TABLE; Schema: test; Owner: sogis_test
--

CREATE TABLE test.test_polygons (
    id integer NOT NULL,
    name character varying(255),
    beschreibung text,
    geom public.geometry(Polygon,2056)
);


ALTER TABLE test.test_polygons OWNER TO sogis_test;

--
-- Name: test_polygons_id_seq; Type: SEQUENCE; Schema: test; Owner: sogis_test
--

CREATE SEQUENCE test.test_polygons_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE test.test_polygons_id_seq OWNER TO sogis_test;

--
-- Name: test_polygons_id_seq; Type: SEQUENCE OWNED BY; Schema: test; Owner: sogis_test
--

ALTER SEQUENCE test.test_polygons_id_seq OWNED BY test.test_polygons.id;


--
-- Name: test_points id; Type: DEFAULT; Schema: test; Owner: sogis_test
--

ALTER TABLE ONLY test.test_points ALTER COLUMN id SET DEFAULT nextval('test.test_points_id_seq'::regclass);


--
-- Name: test_polygons id; Type: DEFAULT; Schema: test; Owner: sogis_test
--

ALTER TABLE ONLY test.test_polygons ALTER COLUMN id SET DEFAULT nextval('test.test_polygons_id_seq'::regclass);


--
-- Data for Name: test_points; Type: TABLE DATA; Schema: test; Owner: sogis_test
--

COPY test.test_points (id, name, beschreibung, geom) FROM stdin;
1	test point1	Point 1	01010000200808000000000000720F3541000000402C6E51C1
2	point2	Point 2	010100002008080000000000004DBC3441000000C00F9151C1
3	point3	Point 3	010100002008080000000000008BD63541000000C0598851C1
\.


--
-- Data for Name: test_polygons; Type: TABLE DATA; Schema: test; Owner: sogis_test
--

COPY test.test_polygons (id, name, beschreibung, geom) FROM stdin;
2	poly2	Polygon 2	01030000200808000001000000050000008040A79B15E935410C5E3734036C51C15933ACD3D9EA3641E74085929C6A51C1D8009459FC8536412D76881D765051C1FD9629D0F940354121174D92FE4F51C18040A79B15E935410C5E3734036C51C1
3	poly3	Polygon 3	0103000020080800000100000005000000EEF90A4069103541D7534EA06F9051C14EC4B96E37E735417294F592D89F51C11BD166F01AA235415648831534C551C1663496A6E2B434415648831534C551C1EEF90A4069103541D7534EA06F9051C1
1	test poly1	Polygon 1	0103000020080800000100000008000000EBA60FA931C0334178B0EC60435351C1BC8F52700E883441850F28ECBA5351C119F5D0AA2195344105CBDA145A7551C1187E6B59E3513441DEE6AABF188751C12CC01B66A0F23341AC6ABD923A8551C195D4ED8DC7A93341C7EFB15C047351C195D4ED8DC7A93341C7EFB15C047351C1EBA60FA931C0334178B0EC60435351C1
\.


--
-- Name: test_points_id_seq; Type: SEQUENCE SET; Schema: test; Owner: sogis_test
--

SELECT pg_catalog.setval('test.test_points_id_seq', 3, true);


--
-- Name: test_polygons_id_seq; Type: SEQUENCE SET; Schema: test; Owner: sogis_test
--

SELECT pg_catalog.setval('test.test_polygons_id_seq', 3, true);


--
-- Name: test_points edit_points_pkey; Type: CONSTRAINT; Schema: test; Owner: sogis_test
--

ALTER TABLE ONLY test.test_points
    ADD CONSTRAINT edit_points_pkey PRIMARY KEY (id);


--
-- Name: test_polygons test_polygons_pkey; Type: CONSTRAINT; Schema: test; Owner: sogis_test
--

ALTER TABLE ONLY test.test_polygons
    ADD CONSTRAINT test_polygons_pkey PRIMARY KEY (id);


--
-- PostgreSQL database dump complete
--

